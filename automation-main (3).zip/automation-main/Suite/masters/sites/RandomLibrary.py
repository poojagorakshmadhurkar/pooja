def capitalize_first_letter(string):
    return string.capitalize()